line = 'Author = {Gooran-Shoorakchaly, Armin and Ahmadchally, Alireza Aghanejad and   Soleimani-Amiri, Samaneh and Gholipour, Morteza},'

iloscand = line.count(' and ')
iloscprzec = line.count(',')
authkey=''

x = line.split("Author = {")
print(x)

if iloscprzec == 1:
    x=x[1].split()
else:
    x=x[1].split('   ')
    print(x)
    for y in x:
        x=y.split(',')
    #x = x[1].split(',')
print(x)
fn = x[0]
print(fn)


#for y in x:
#    if y==' I,' or y==' II,' or y==' III,' or y==' IV,' or y==' V,' or y==' VI,' or y==' VII,' or y==' VIII,' or y==' IX,' or y==' X,' or y==' XI,' or y==' XI,' or y==' XII,' or y==' XII,' or y==' XIV,' or y==' XV,':
#        y=''
    
if len(fn) < 4:
    authkey = fn
else:
    nfn =''
    nfn += fn[0:3]
    authkey += nfn
if iloscand < 1:
    print(authkey)
if iloscand == 1:
    sn = x[1]
    sn = sn.strip()
    sn = sn.split(' and ')
    sn = sn[1]
    if len(sn) < 4:
        authkey += sn
    else:
        nsn =''
        nsn += sn[0:3]
        authkey += nsn
        print(authkey)
if iloscand == 2:
    sn = x[1]
    sn = sn.strip()
    sn = sn.split(' and ')
    sn = sn[1]
    if len(sn) < 4:
        authkey += sn
    else:
        nsn =''
        nsn += sn[0:3]
        authkey += nsn
    tn = x[2]
    tn = tn.strip()
    tn = tn.split(' and ')
    tn = tn[1]
    if len(tn) < 4:
        authkey += tn
    else:
        ntn =''
        ntn += tn[0:3]
        authkey += ntn
    print(authkey)
if iloscand > 2:
    sn = x[1]
    print(sn)
    sn = sn.strip()
    print(sn)
    sn = sn.split(' and ')
    print(sn)
    sn = sn[1]
    if len(sn) < 4:
        authkey += sn
    else:
        nsn =''
        nsn += sn[0:3]
        authkey += nsn
    tn = x[2]
    tn = tn.strip()
    tn = tn.split(' and ')
    tn = tn[1]
    if len(tn) < 4:
        authkey += tn
    else:
        ntn =''
        ntn += tn[0:3]
        authkey += ntn
        authkey+='ETAL'
    print(authkey)
